package com.educacionit.telecom.digitalers.clasesfinales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClasesfinalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
