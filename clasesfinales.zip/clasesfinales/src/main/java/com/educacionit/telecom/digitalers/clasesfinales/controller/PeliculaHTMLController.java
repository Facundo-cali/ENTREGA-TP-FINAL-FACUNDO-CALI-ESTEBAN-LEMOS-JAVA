package com.educacionit.telecom.digitalers.clasesfinales.controller;

import com.educacionit.telecom.digitalers.clasesfinales.inter.IPelicula;
import com.educacionit.telecom.digitalers.clasesfinales.pojos.Pelicula;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@Controller
@RequestMapping("pelicula")
public class PeliculaHTMLController {
	@Autowired
	private IPelicula ipeli;

	// Método para mostrar el HTML con el formulario de registro de películas
	@GetMapping("crearPelicula")
	public String mostrarFormulario() {
		return "crearPelicula"; // No es necesario incluir la extensión .html
	}

	// Método para guardar en la bd
	@PostMapping("registrar")
	public String crearPelicula(@RequestParam("titulo") String titulo, @RequestParam("ano_lanzamiento") Integer ano_lanzamiento,
								@RequestParam("genero") String genero, @RequestParam("director") String director,
								@RequestParam("sinopsis") String sinopsis, @RequestParam ("duracion") String duracion, @RequestParam("imagen") String imagen) {
		Pelicula peli = new Pelicula(titulo, ano_lanzamiento, genero, director, sinopsis,duracion, imagen);
		ipeli.save(peli);
		return "redirect:/";
	}


	// Método para mostrar el HTML con el formulario de registro de películas
	@GetMapping("editarPelicula/{id}")
	public String mostrarFormularioEdicion() {
		return "editarPelicula"; // No es necesario incluir la extensión .html
	}

	@PostMapping("editar/{id}")
	public String editarPelicula(@PathVariable("id") Integer id,
								 @RequestParam("titulo") String titulo,
								 @RequestParam("ano_lanzamiento") Integer anoLanzamiento,
								 @RequestParam("genero") String genero,
								 @RequestParam("director") String director,
								 @RequestParam("sinopsis") String sinopsis,
								 @RequestParam("duracion") String duracion,
								 @RequestParam("imagen") String imagen) {

		// Aquí deberías usar el ID para buscar y editar la película correspondiente
		Optional<Pelicula> peliculaOptional = ipeli.findById(id);

		if (peliculaOptional.isPresent()) {
			Pelicula pelicula = peliculaOptional.get();

			// Actualizar los campos de la película
			pelicula.setTitulo(titulo);
			pelicula.setAno_lanzamiento(anoLanzamiento);
			pelicula.setGenero(genero);
			pelicula.setDirector(director);
			pelicula.setSinopsis(sinopsis);
			pelicula.setDuracion(duracion);
			pelicula.setImagen(imagen);

			// Guardar la película actualizada
			ipeli.save(pelicula);
		}

		return "redirect:/"; // Redirige a la página principal
	}

	// Método para borrar
	@DeleteMapping("borrar/{id}")
	public String borrar(@PathVariable("id") Integer id) {
		ipeli.deleteById(id);
		return "redirect:/";
	}
}
