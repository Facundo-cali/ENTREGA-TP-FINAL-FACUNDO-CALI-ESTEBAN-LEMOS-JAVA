package com.educacionit.telecom.digitalers.clasesfinales.inter;

import com.educacionit.telecom.digitalers.clasesfinales.pojos.Pelicula;
import org.springframework.data.jpa.repository.JpaRepository;


public interface IPelicula extends JpaRepository<Pelicula, Integer> {

}
