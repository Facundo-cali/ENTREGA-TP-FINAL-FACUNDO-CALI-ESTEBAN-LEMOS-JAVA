package com.educacionit.telecom.digitalers.clasesfinales.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Pelicula {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@Column
	private String titulo;
	@Column
	private Integer ano_lanzamiento;
	@Column
	private String genero;
	@Column
	private String director;
	@Column
	private String sinopsis;
	@Column
	private String duracion;
	@Column
	private String imagen;

	public Pelicula() {
	}

	public Pelicula (String titulo, Integer ano_lanzamiento, String genero, String director, String sinopsis, String duracion, String imagen) {
		this.titulo = titulo;
		this.ano_lanzamiento = ano_lanzamiento;
		this.genero = genero;
		this.director = director;
		this.sinopsis = sinopsis;
		this.duracion = duracion;
		this.imagen = imagen;
	}

	public Integer getId() {
		return id;
	}

	public String getTitulo() {
		return titulo;
	}

	public Integer getAno_lanzamiento() {
		return ano_lanzamiento;
	}

	public String getGenero() {
		return genero;
	}

	public String getDirector() {
		return director;
	}

	public String getSinopsis() {
		return sinopsis;
	}

	public String getDuracion() {
		return duracion;
	}

	public String getImagen() {
		return imagen;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setAno_lanzamiento(Integer ano_lanzamiento) {
		this.ano_lanzamiento = ano_lanzamiento;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public void setSinopsis(String sinopsis) {
		this.sinopsis = sinopsis;
	}

	public void setDuracion(String duracion) {
		this.duracion = duracion;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	@Override
	public String toString() {
		return
				"Pelicula{" +
		"id=" + id +
		", titulo='" + titulo + '\'' +
		", ano_lanzamiento=" + ano_lanzamiento +
		", sinopsis='" + sinopsis + '\'' +
		", imagen='" + imagen + '\'' ;
	}

}
