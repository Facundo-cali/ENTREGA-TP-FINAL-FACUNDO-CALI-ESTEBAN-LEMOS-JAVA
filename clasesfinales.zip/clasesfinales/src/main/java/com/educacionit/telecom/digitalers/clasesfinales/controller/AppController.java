package com.educacionit.telecom.digitalers.clasesfinales.controller;

import java.util.Arrays;
import java.util.List;

import com.educacionit.telecom.digitalers.clasesfinales.pojos.Pelicula;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.educacionit.telecom.digitalers.clasesfinales.inter.IPelicula;

@CrossOrigin
//@Controller // Controller se usa cuando queremos que nos devuelva una vista
@RestController // RestController se usa cuando queremos que nos devuelva un JSON
@RequestMapping("pelicula")
public class AppController {
	@Autowired
	private IPelicula ipeli;

	// Método para llamar al index html
	@GetMapping("index")
	public String mostrarIndex() {
		return "index";
	}


	// Método para consultar en la base de datos y mostrar los usuarios
	@GetMapping("lista")
	public List<Pelicula> mostrarPeliculas() {
		return this.ipeli.findAll();
	}


	@GetMapping("/buscar/{id}")
	public Pelicula buscarPeliculaPorId(@PathVariable("id") Integer id) {
		// Utiliza el repositorio para buscar la película por ID
		return ipeli.findById(id).orElse(null);
	}
}
